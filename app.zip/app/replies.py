"""Composing the reply the rider reads.

Code assembles a fact bundle from the decisions; this module turns it into
Hinglish. The facts are produced before any language is generated, so a model
polishing the wording cannot invent an amount or drop an order id -- the
sample conversations are checked on exactly those substrings.

Templates are the default rather than a fallback: they are reproducible, they
cost nothing, and in this domain the rider wants the number, not prose. A model
is used only to smooth phrasing when one is configured, and never to decide
what the facts are.
"""

from __future__ import annotations

from datetime import date

from app.decide import Action, Decision

MONTH_SHORT = {
    1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
    7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec",
}


def _day_text(value: str | date | None) -> str:
    if value is None:
        return ""
    day = value if isinstance(value, date) else date.fromisoformat(str(value))
    return f"{day.day} {MONTH_SHORT[day.month]}"


def _reason_sentences(decision: Decision) -> list[str]:
    """One sentence per component of the shortfall, each with its figures."""
    out: list[str] = []
    settlement = decision.settlement
    if settlement is None:
        return out

    for reason in settlement.reasons:
        day = _day_text(reason.day)
        if reason.kind == "surge_or_fare_short":
            owed, paid = reason.detail.get("owed"), reason.detail.get("paid")
            surge = reason.detail.get("surge_multiplier")
            if surge and float(surge) > 1.0:
                out.append(
                    f"{day} ko order {reason.trip_id} pe {surge}x surge laga tha: "
                    f"Rs{owed} banta tha, Rs{paid} mila."
                )
            else:
                out.append(
                    f"{day} ko order {reason.trip_id} ka fare Rs{owed} banta tha, "
                    f"Rs{paid} mila."
                )
        elif reason.kind == "trip_unpaid":
            out.append(
                f"{day} ko order {reason.trip_id} ka Rs{reason.amount} payout "
                "bilkul nahi gaya tha."
            )
        elif reason.kind == "incentive_missing":
            trips = reason.detail.get("completed_trips")
            out.append(
                f"{day} ko aapke {trips} trips complete hue the, "
                f"to Rs{reason.amount} ka daily incentive banta tha."
            )
        elif reason.kind == "penalty_duplicated":
            times = reason.detail.get("times_charged")
            out.append(
                f"{day} ko order {reason.trip_id} ka cancel penalty {times} baar kata, "
                f"Rs{reason.amount} extra kat gaya."
            )
    return out


def _explain_nothing_owed(decision: Decision) -> str:
    settlement = decision.settlement
    if settlement is None:
        return "Humare record mein is par koi kami nahi mili."

    parts: list[str] = []
    for flag in settlement.flags:
        if flag.kind == "incentive_not_earned":
            trips = flag.detail.get("completed_trips")
            threshold = flag.detail.get("threshold")
            day = _day_text(flag.detail.get("day"))
            parts.append(
                f"{day} ko aapke {trips} trips complete hue the. "
                f"Incentive {threshold} trips pe milta hai, isliye nahi bana."
            )
        elif flag.kind == "incentive_already_paid":
            day = _day_text(flag.detail.get("day"))
            parts.append(f"{day} ka daily incentive already aapke payout mein gaya hai.")
        elif flag.kind == "trip_paid_correctly":
            owed = flag.detail.get("owed")
            surge = flag.detail.get("surge_multiplier")
            km = flag.detail.get("distance_km")
            surge_text = (
                f" {surge}x surge ke saath" if surge and float(surge) > 1.0 else " (koi surge nahi tha)"
            )
            parts.append(
                f"Order {flag.trip_id}: {km} km{surge_text}, Rs{owed} banta tha "
                f"aur Rs{owed} hi mila hai."
            )
        elif flag.kind == "penalty_legitimate":
            parts.append(
                f"Order {flag.trip_id} aapne cancel kiya tha, isliye Rs10 ka "
                "cancellation penalty laga hai."
            )
        elif flag.kind == "customer_cancellation":
            parts.append(
                f"Order {flag.trip_id} customer ne cancel kiya tha. Customer "
                "cancellation pe koi payment nahi banta, aur penalty bhi nahi lagti."
            )
        elif flag.kind == "unknown_trip":
            parts.append(
                f"Order {flag.trip_id} humare system mein nahi mil raha."
            )
        elif flag.kind == "overpaid":
            parts.append(
                f"Order {flag.trip_id} ka payment poora gaya hai."
            )
        elif flag.kind == "no_trips_that_day":
            day = _day_text(flag.detail.get("day"))
            parts.append(f"{day} ko humare record mein koi trip nahi hai.")

    if not parts:
        parts.append("Humare record ke hisaab se poora payment ho gaya hai.")
    return " ".join(parts)


def compose(decisions: list[Decision], payment_results: dict[int, object]) -> str:
    """Build the rider's reply from the decisions, in the order they were made."""
    sentences: list[str] = []

    for index, decision in enumerate(decisions):
        if decision.action == Action.CLARIFY:
            sentences.append(
                "Kaunse din ya kaunse order ka payout galat laga? "
                "Date ya order ID bata dijiye, main check kar deta hoon."
            )

        elif decision.action == Action.PAY:
            sentences.extend(_reason_sentences(decision))
            result = payment_results.get(index)
            moved = getattr(result, "money_moved", False)
            if moved:
                sentences.append(
                    f"Farak Rs{decision.amount} ka payment PaySwift pe process ho gaya hai."
                )
            else:
                sentences.append(
                    f"Rs{decision.amount} ka payment process kar rahe hain, "
                    "thodi der mein aa jayega."
                )

        elif decision.action == Action.APPROVAL:
            sentences.extend(_reason_sentences(decision))
            if decision.rule == "auto_pay_already_used_today":
                sentences.append(
                    f"Ek din mein ek hi auto-payment ho sakta hai, isliye Rs{decision.amount} "
                    "ops team approve karegi."
                )
            else:
                sentences.append(
                    f"Rs{decision.amount} ka amount auto-payment limit se zyada hai, "
                    "isliye ops team approve karegi. Approve hote hi aa jayega."
                )

        elif decision.action == Action.EXPLAIN:
            if decision.rule == "nothing_owed":
                sentences.append(_explain_nothing_owed(decision))
            elif decision.rule == "already_compensated":
                sentences.append(
                    "Is order ka farak hum already process kar chuke hain, "
                    "dobara payment nahi hoga. Agar abhi tak nahi aaya to ops team dekh legi."
                )
            elif decision.rule == "status_question":
                sentences.append(
                    "Aapka case process ho chuka hai. Payment PaySwift se aata hai, "
                    "pending approval ho to ops approve karte hi aa jayega."
                )

        elif decision.action == Action.ESCALATION:
            if decision.rule == "outside_dispute_window":
                flag = next(
                    (f for f in decision.settlement.flags if f.kind == "outside_window"),
                    None,
                ) if decision.settlement else None
                days_ago = flag.detail.get("days_ago") if flag else None
                sentences.append(
                    f"Ye order {days_ago} din purana hai aur hum sirf last 7 din ke "
                    "disputes dekh paate hain. Main ise ops team ko bhej raha hoon."
                    if days_ago
                    else "Ye dispute 7 din se purana hai, main ise ops team ko bhej raha hoon."
                )
            elif decision.rule == "rider_disputes_our_records":
                sentences.append(
                    "Dobara check kiya, humare record mein wahi number aa raha hai. "
                    "Agar aapko lagta hai record galat hai, main ise ops team ko bhej deta hoon."
                )
            elif decision.rule == "identity_claim_ignored":
                sentences.append(
                    "Main sirf isi number se jude rider ka payout check kar sakta hoon. "
                    "Kisi dusre rider ke liye ops team se baat karni hogi."
                )
            elif decision.rule == "prompt_injection_attempt":
                sentences.append(
                    "Main sirf payout disputes check karta hoon aur policy ke bahar "
                    "payment nahi kar sakta. Aapka message ops team ko bhej diya hai."
                )
            elif decision.rule == "trip_belongs_to_another_rider":
                sentences.append(
                    "Ye order aapke record mein nahi mil raha. Main ise ops team se "
                    "check karwa raha hoon."
                )
            elif decision.rule == "unknown_trip_id":
                sentences.append(
                    "Ye order ID humare system mein nahi mili. Ek baar ID check kar ke "
                    "bata dijiye, ya main ops team se dekhwa leta hoon."
                )
            elif decision.rule == "classifier_disagreement":
                sentences.append(
                    "Aapki baat samajhne mein confusion hui, isliye main ise ops team ko "
                    "bhej raha hoon taaki koi galti na ho."
                )
            else:
                sentences.extend(_reason_sentences(decision))
                sentences.append(
                    "Is case ko verify karne ke liye main ise ops team ko bhej raha hoon, "
                    "wo aapko update denge."
                )

    # Deduplicate while keeping order: two claims can produce the same closing line.
    seen: set[str] = set()
    unique = [s for s in sentences if not (s in seen or seen.add(s))]
    return " ".join(unique) or "Aapka message mil gaya hai, main check kar raha hoon."
